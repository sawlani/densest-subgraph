#ifndef _VALUES_H_
#define _VALUES_H_

#define MAXLONG 1073741824
#define atoll (long long) atof

#endif
